
function blow(){
document.getElementById('candle').innerHTML='💨';
document.getElementById('msg').innerHTML='Happy 17th Birthday Maaz! 💖🎉';
}
